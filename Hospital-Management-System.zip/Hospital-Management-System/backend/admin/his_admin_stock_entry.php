<?php
session_start();
include('assets/inc/config.php');

// Fetch pharmaceuticals for the dropdown
$pharmaceuticals_query = "SELECT phar_id, phar_name FROM his_pharmaceuticals";
$pharmaceuticals_result = $mysqli->query($pharmaceuticals_query);

// Fetch warehouses for the dropdown
$warehouses_query = "SELECT warehouse_id, warehouse_name FROM warehouses";
$warehouses_result = $mysqli->query($warehouses_query);

// Generate a unique token for the form to prevent resubmission
if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32)); // Generate a secure random token
}

// Check if the form has been submitted and process it
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_stock'])) {
    // Prevent resubmission if the token does not match
    if (!isset($_POST['form_token']) || $_POST['form_token'] !== $_SESSION['form_token']) {
        $_SESSION['err'] = "Form already submitted or invalid session.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Unset the token to prevent resubmission on page reload
    unset($_SESSION['form_token']); 

    // Process the form submission
    $entry_type = $_POST['entry_type']; // receipt, transfer, or issue
    $entry_date = $_POST['entry_date']; // Get the date from the form
    $remarks = $_POST['remarks'];
    $warehouse_id = $_POST['warehouse_id']; // New field for warehouse

    // Fetch the warehouse name based on warehouse_id
    $warehouse_name = '';
    $warehouse_query = "SELECT warehouse_name FROM warehouses WHERE warehouse_id = ?";
    $stmt = $mysqli->prepare($warehouse_query);
    $stmt->bind_param('i', $warehouse_id);
    $stmt->execute();
    $stmt->bind_result($warehouse_name);
    $stmt->fetch();
    $stmt->close();

    if (empty($warehouse_name)) {
        $_SESSION['err'] = "Invalid warehouse selected.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Check if pharmaceuticals are selected
    if (isset($_POST['phar_id']) && is_array($_POST['phar_id'])) {
        foreach ($_POST['phar_id'] as $key => $phar_id) {
            // Fetch the pharmaceutical name from the database based on phar_id
            $phar_name = '';
            $phar_query = "SELECT phar_name FROM his_pharmaceuticals WHERE phar_id = ?";
            $stmt = $mysqli->prepare($phar_query);
            $stmt->bind_param('i', $phar_id);
            $stmt->execute();
            $stmt->bind_result($phar_name);
            $stmt->fetch();
            $stmt->close();

            if (empty($phar_name)) {
                $_SESSION['err'] = "Invalid pharmaceutical selected.";
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            }

            $entry_quantity = $_POST['entry_quantity'][$key]; // Quantity

            // Insert stock entry details into a log table, including the date
            $query = "INSERT INTO stock_entries (phar_id, phar_name, entry_type, entry_quantity, remarks, warehouse, entry_date) 
                      VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($query);
            if ($stmt) {
                $stmt->bind_param('isssiss', $phar_id, $phar_name, $entry_type, $entry_quantity, $remarks, $warehouse_name, $entry_date);
                $stmt->execute();
                $stmt->close();
            } else {
                $_SESSION['err'] = "Error adding stock entry.";
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            }

            // Update stock quantity based on entry type
            if ($entry_type === 'receipt') {
                $update_query = "UPDATE his_pharmaceuticals SET phar_qty = phar_qty + ? WHERE phar_id = ?";
            } elseif ($entry_type === 'issue') {
                $update_query = "UPDATE his_pharmaceuticals SET phar_qty = phar_qty - ? WHERE phar_id = ?";
            } else {
                $update_query = null; // No stock changes for transfer
            }

            if ($update_query) {
                $update_stmt = $mysqli->prepare($update_query);
                if ($update_stmt) {
                    $update_stmt->bind_param('ii', $entry_quantity, $phar_id);
                    $update_stmt->execute();
                    $update_stmt->close();
                } else {
                    $_SESSION['err'] = "Error updating stock quantity.";
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                }
            }
        }
    } else {
        $_SESSION['err'] = "No pharmaceuticals selected.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    // Feedback to user
    $_SESSION['success'] = "Stock Entry Added Successfully";

    // Redirect to prevent resubmission and break the redirect loop
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>




<!DOCTYPE html>
<html lang="en">
<!-- Head -->
<?php include('assets/inc/head.php'); ?>
<link href="path/to/metisMenu.min.css" rel="stylesheet">

<body>
    <div id="wrapper">
        <!-- Topbar -->
        <?php include("assets/inc/nav.php"); ?>
        <!-- Sidebar -->
        <?php include("assets/inc/sidebar.php"); ?>

        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="#">Stock</a></li>
                                        <li class="breadcrumb-item active">Add Stock Entry</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Add Stock Entry</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Fill All Fields</h4>

                                    <!-- Display Messages -->
                                    <?php if (isset($_SESSION['success'])): ?>
                                        <div class="alert alert-success">
                                            <?php 
                                            echo $_SESSION['success']; 
                                            unset($_SESSION['success']); 
                                            ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (isset($_SESSION['err'])): ?>
                                        <div class="alert alert-danger">
                                            <?php 
                                            echo $_SESSION['err']; 
                                            unset($_SESSION['err']); 
                                            ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Form -->
                                    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                                        <div class="form-group">
                                            <label for="entry_date" class="col-form-label">Entry Date</label>
                                            <input required="required" type="date" name="entry_date" class="form-control" id="entry_date" value="<?php echo date('Y-m-d'); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="entry_type" class="col-form-label">Stock Entry Type</label>
                                            <select required="required" class="form-control" name="entry_type" id="entry_type">
                                                <option value="receipt">Receipt</option>
                                                <option value="issue">Issue</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="warehouse_id" class="col-form-label">Select Warehouse</label>
                                            <select id="warehouse_id" name="warehouse_id" class="form-control" required>
                                                <option value="">-- Select Warehouse --</option>
                                                <?php
                                                if ($warehouses_result->num_rows > 0) {
                                                    while ($row = $warehouses_result->fetch_assoc()) {
                                                        echo "<option value='{$row['warehouse_id']}'>{$row['warehouse_name']}</option>";
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>

                                        <table id="stock-table" class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Quantity</th>
                                                    <th>Remarks</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <select name="phar_id[]" class="form-control" required>
                                                            <option value="">-- Select Pharmaceutical --</option>
                                                            <?php
                                                            if ($pharmaceuticals_result->num_rows > 0) {
                                                                while ($row = $pharmaceuticals_result->fetch_assoc()) {
                                                                    echo "<option value='{$row['phar_id']}'>{$row['phar_name']}</option>";
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </td>
                                                    <td><input type="number" name="entry_quantity[]" class="form-control" required></td>
                                                    <td><input type="text" name="remarks[]" class="form-control"></td>
                                                    <td><button type="button" class="btn btn-danger remove-row">Remove</button></td>
                                                </tr>
                                            </tbody>
                                        </table>

                                        <!-- Add Row Button -->
                                        <button type="button" class="btn btn-primary" id="add-row">Add Row</button>
                                        <br><br>

                                        <!-- Submit Button -->
                                        <div class="form-group">
                                            <button type="submit" name="add_stock" class="btn btn-success">Add Stock Entry</button>
                                        </div>

                                        <!-- Hidden Token Field -->
                                        <input type="hidden" name="form_token" value="<?php echo $_SESSION['form_token']; ?>">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>

    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Include Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />

    <!-- Include Select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

    <script src="path/to/metisMenu.min.js"></script>

    <!-- App js -->
    <script src="assets/js/app.min.js"></script>

    <script>
        $(document).ready(function () {
    // Initialize Select2 for pharmaceutical and warehouse selection
    $('#phar_id, #warehouse_id').select2({
        placeholder: 'Search and select',
        allowClear: true
    });

    // Add row functionality
    $('#add-row').click(function() {
        var newRow = $('#stock-table tbody tr:first').clone(); // Clone first row
        newRow.find('input').val(''); // Reset all input fields in the new row
        $('#stock-table tbody').append(newRow); // Append the cloned row
    });

    // Remove row functionality using event delegation for dynamically added rows
    $(document).on('click', '.remove-row', function() {
        $(this).closest('tr').remove(); // Remove the row
    });
});

    </script>
</body>
</html>
