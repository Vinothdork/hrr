<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['add_acc'])) {
    // Get the form data
    $acc_name = $_POST['acc_name'];
    $acc_type = $_POST['acc_type'];
    $acc_number = $_POST['acc_number'];
    $acc_amount = $_POST['acc_amount'];
    $acc_person_type = $_POST['acc_person_type'];  // Employee or Vendor
    $acc_person_id = $_POST[$acc_person_type . '_id'];  // Employee or Vendor ID

    // SQL to insert captured values into the table
    $query = "INSERT INTO his_accounts (acc_name, acc_type, acc_number, acc_amount, acc_person_type, acc_person_id)
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $mysqli->prepare($query);
    $rc = $stmt->bind_param('ssssss', $acc_name, $acc_type, $acc_number, $acc_amount, $acc_person_type, $acc_person_id);
    $stmt->execute();

    // Declare a variable for success or error
    if ($stmt) {
        $success = "Account Payable Details Added";
    } else {
        $err = "Please Try Again Or Try Later";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <!-- Head -->
    <?php include('assets/inc/head.php'); ?>
    <body>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- Topbar Start -->
            <?php include("assets/inc/nav.php"); ?>
            <!-- end Topbar -->

            <!-- ========== Left Sidebar Start ========== -->
            <?php include("assets/inc/sidebar.php"); ?>
            <!-- Left Sidebar End -->

            <!-- Start Page Content here -->
            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- Page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Payable Account Details</h4>
                                </div>
                            </div>
                        </div>     
                        
                        <!-- Form row -->
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Fill all fields</h4>
                                        <!-- Add Account Form -->
                                        <form method="post">
                                        <div class="form-group">
                                                <label for="acc_person_type">Select Payment For</label>
                                                <select class="form-control" name="acc_person_type" id="acc_person_type" onchange="showPersonField(this.value)" required>
                                                    <option value="">Select</option>
                                                    <option value="employee">Employee</option>
                                                    <option value="vendor">Vendor</option>
                                                </select>
                                            </div>

                                            <!-- Employee Selection (Dynamic) -->
                                            <div id="employee_field" style="display:none;">
                                                <label for="employee_id">Select Employee</label>
                                                <select class="form-control" name="employee_id" id="employee_id">
                                                    <?php 
                                                        $emp_query = "SELECT doc_id, doc_fname, doc_lname FROM his_docs";
                                                        $result = $mysqli->query($emp_query);
                                                        while($row = $result->fetch_assoc()) {
                                                            echo "<option value='{$row['doc_id']}'>{$row['doc_fname']} {$row['doc_lname']}</option>";
                                                        }
                                                    ?>
                                                </select>
                                            </div>

                                            <!-- Vendor Selection (Dynamic) -->
                                            <div id="vendor_field" style="display:none;">
                                                <label for="vendor_id">Select Vendor</label>
                                                <select class="form-control" name="vendor_id" id="vendor_id">
                                                    <?php 
                                                        $vendor_query = "SELECT v_id, v_name FROM his_vendor";
                                                        $result = $mysqli->query($vendor_query);
                                                        while($row = $result->fetch_assoc()) {
                                                            echo "<option value='{$row['v_id']}'>{$row['v_name']}</option>";
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="form-row">
                                                <!-- Account Name -->
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail4" class="col-form-label">Account Name</label>
                                                    <input type="text" required="required" name="acc_name" class="form-control" id="inputEmail4">
                                                </div>
                                                
                                                <!-- Account Amount -->
                                                <div class="form-group col-md-6">
                                                    <label for="inputEmail4" class="col-form-label">Account Amount($)</label>
                                                    <input type="text" required="required" name="acc_amount" class="form-control" id="inputEmail4">
                                                </div>
                                            </div>

                                            <!-- Hidden Account Number -->
                                            <div class="form-group col-md-2" style="display:none">
                                                <?php 
                                                    $length = 15;    
                                                    $account_number = substr(str_shuffle('0123456789'), 1, $length);
                                                ?>
                                                <label for="inputZip" class="col-form-label">Account Number</label>
                                                <input type="text" name="acc_number" value="<?php echo $account_number; ?>" class="form-control" id="inputZip">
                                            </div>

                                            <!-- Account Type (Payable) -->
                                            <div class="form-group" style="display:none">
                                                <label for="inputAddress" class="col-form-label">Account Type</label>
                                                <input required="required" value="Payable Account" type="text" class="form-control" name="acc_type" id="inputAddress">
                                            </div>

                                            <!-- Submit Button -->
                                            <button type="submit" name="add_acc" class="btn btn-success">Add Account</button>

                                        </form>
                                    </div> <!-- end card-body -->
                                </div> <!-- end card -->
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div> <!-- container -->

                </div> <!-- content -->

                <!-- Footer Start -->
                <?php include('assets/inc/footer.php'); ?>
                <!-- end Footer -->

            </div>

        </div>
        
        <!-- Right bar overlay -->
        <div class="rightbar-overlay"></div>

        <script src="//cdn.ckeditor.com/4.6.2/basic/ckeditor.js"></script>
        <script type="text/javascript">
            CKEDITOR.replace('editor');

            // Function to show the correct selection fields based on user selection
            function showPersonField(value) {
                if (value == "employee") {
                    document.getElementById("employee_field").style.display = "block";
                    document.getElementById("vendor_field").style.display = "none";
                } else if (value == "vendor") {
                    document.getElementById("employee_field").style.display = "none";
                    document.getElementById("vendor_field").style.display = "block";
                } else {
                    document.getElementById("employee_field").style.display = "none";
                    document.getElementById("vendor_field").style.display = "none";
                }
            }
        </script>

        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!-- App js-->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>
