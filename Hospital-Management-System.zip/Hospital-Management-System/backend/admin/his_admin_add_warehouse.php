<?php
session_start();
include('assets/inc/config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_warehouse'])) {
    $warehouse_name = $_POST['warehouse_name'];
    $warehouse_location = $_POST['warehouse_location'];

    // SQL to insert captured values
    $query = "INSERT INTO warehouses (warehouse_name, warehouse_location) VALUES (?, ?)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('ss', $warehouse_name, $warehouse_location);
    $stmt->execute();

    // Feedback to the user
    if ($stmt) {
        $_SESSION['success'] = "Warehouse Added Successfully!";
    } else {
        $_SESSION['err'] = "Failed to Add Warehouse. Please Try Again.";
    }

    // Redirect to prevent duplicate submission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
    <!--Head-->
    <?php include('assets/inc/head.php'); ?>
    <body>
        <div id="wrapper">
            <!-- Topbar -->
            <?php include("assets/inc/nav.php"); ?>
            <!-- Sidebar -->
            <?php include("assets/inc/sidebar.php"); ?>

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid">
                        <!-- Page Title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Add New Warehouse</h4>
                                </div>
                            </div>
                        </div>

                        <!-- Form Section -->
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Enter Warehouse Details</h4>

                                        <!-- Display Messages -->
                                        <?php if (isset($_SESSION['success'])): ?>
                                            <div class="alert alert-success">
                                                <?php 
                                                echo $_SESSION['success']; 
                                                unset($_SESSION['success']); 
                                                ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (isset($_SESSION['err'])): ?>
                                            <div class="alert alert-danger">
                                                <?php 
                                                echo $_SESSION['err']; 
                                                unset($_SESSION['err']); 
                                                ?>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Form -->
                                        <form method="post" action="">
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="warehouse_name" class="col-form-label">Warehouse Name</label>
                                                    <input type="text" required name="warehouse_name" class="form-control" id="warehouse_name">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="warehouse_location" class="col-form-label">Warehouse Location</label>
                                                    <input type="text" name="warehouse_location" class="form-control" id="warehouse_location">
                                                </div>
                                            </div>
                                            <button type="submit" name="add_warehouse" class="btn btn-success">Add Warehouse</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <?php include('assets/inc/footer.php'); ?>
            </div>
        </div>

        <!-- Scripts -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>
    </body>
</html>
