<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['admit_patient'])) {
    if (isset($_POST['is_registered']) && $_POST['is_registered'] == 'yes') {
        // Handle admission for registered patient
        $pat_id = $_POST['pat_id'];
        $admission_reason = $_POST['admission_reason'];
        $admission_date = $_POST['admission_date'];

        $query = "INSERT INTO patient_admissions (pat_id, admission_reason, admission_date) VALUES (?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('sss', $pat_id, $admission_reason, $admission_date);
        $stmt->execute();

        if ($stmt) {
            $success = "Patient admitted successfully!";
        } else {
            $err = "Error admitting patient. Please try again.";
        }
    } else {
        // Handle new patient registration and admission
        $pat_fname = $_POST['pat_fname'];
        $pat_lname = $_POST['pat_lname'];
        $pat_dob = $_POST['pat_dob'];
        $pat_age = $_POST['pat_age'];
        $pat_number = $_POST['pat_number'];
        $pat_addr = $_POST['pat_addr'];
        $pat_phone = $_POST['pat_phone'];
        $pat_type = $_POST['pat_type'];
        $pat_ailment = $_POST['pat_ailment'];
        $admission_reason = $_POST['admission_reason'];
        $admission_date = $_POST['admission_date'];

        // Insert new patient details
        $query1 = "INSERT INTO his_patients (pat_fname, pat_lname, pat_dob, pat_age, pat_number, pat_addr, pat_phone, pat_type, pat_ailment) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt1 = $mysqli->prepare($query1);
        $stmt1->bind_param('sssssssss', $pat_fname, $pat_lname, $pat_dob, $pat_age, $pat_number, $pat_addr, $pat_phone, $pat_type, $pat_ailment);
        $stmt1->execute();

        if ($stmt1) {
            $pat_id = $mysqli->insert_id; // Get the last inserted patient ID

            // Insert admission details
            $query2 = "INSERT INTO patient_admissions (pat_id, admission_reason, admission_date) VALUES (?, ?, ?)";
            $stmt2 = $mysqli->prepare($query2);
            $stmt2->bind_param('sss', $pat_id, $admission_reason, $admission_date);
            $stmt2->execute();

            if ($stmt2) {
                $success = "New patient registered and admitted successfully!";
            } else {
                $err = "Error admitting new patient. Please try again.";
            }
        } else {
            $err = "Error registering new patient. Please try again.";
        }
    }
}

// Fetch registered patients for the dropdown
$patients = [];
$query = "SELECT pat_id, CONCAT(pat_fname, ' ', pat_lname) AS pat_name FROM his_patients";
$result = $mysqli->query($query);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $patients[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>
<body>
<div id="wrapper">
    <?php include("assets/inc/nav.php"); ?>
    <?php include("assets/inc/sidebar.php"); ?>

    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Patient Admission</h4>
                                <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
                                <?php if (isset($err)) echo "<div class='alert alert-danger'>$err</div>"; ?>

                                <form method="post">
                                    <div class="form-group">
                                        <label><input type="checkbox" id="is_registered" name="is_registered" value="yes"> Registered Patient</label>
                                    </div>

                                    <div id="registered-patient" style="display: none;">
                                        <div class="form-group">
                                            <label for="pat_id">Select Patient</label>
                                            <select class="form-control" name="pat_id" id="pat_id">
                                                <option value="">Choose Patient</option>
                                                <?php foreach ($patients as $patient): ?>
                                                    <option value="<?php echo $patient['pat_id']; ?>"><?php echo $patient['pat_name']; ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div id="new-patient">
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>First Name</label>
                                                <input type="text" name="pat_fname" class="form-control">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Last Name</label>
                                                <input type="text" name="pat_lname" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Date of Birth</label>
                                                <input type="text" name="pat_dob" class="form-control">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Age</label>
                                                <input type="text" name="pat_age" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Address</label>
                                            <input type="text" name="pat_addr" class="form-control">
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label>Phone</label>
                                                <input type="text" name="pat_phone" class="form-control">
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label>Patient Type</label>
                                                <select name="pat_type" class="form-control">
                                                    <option>InPatient</option>
                                                    <option>OutPatient</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Ailment</label>
                                            <input type="text" name="pat_ailment" class="form-control">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>Reason for Admission</label>
                                        <input type="text" name="admission_reason" class="form-control">
                                    </div>

                                    <div class="form-group">
                                        <label>Admission Date</label>
                                        <input type="date" name="admission_date" class="form-control">
                                    </div>

                                    <button type="submit" name="admit_patient" class="btn btn-primary">Admit Patient</button>
                                </form>

                                <script>
                                    document.getElementById('is_registered').addEventListener('change', function () {
                                        if (this.checked) {
                                            document.getElementById('registered-patient').style.display = 'block';
                                            document.getElementById('new-patient').style.display = 'none';
                                        } else {
                                            document.getElementById('registered-patient').style.display = 'none';
                                            document.getElementById('new-patient').style.display = 'block';
                                        }
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('assets/inc/footer.php'); ?>
    </div>
</div>
<script src="assets/js/vendor.min.js"></script>
<script src="assets/js/app.min.js"></script>
</body>
</html>
