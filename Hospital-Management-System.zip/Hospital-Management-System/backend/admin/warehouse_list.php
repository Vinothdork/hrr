<?php
    session_start();
    include('assets/inc/config.php'); // Include the database configuration

    // Fetch warehouse list from the database
    $query = "SELECT * FROM warehouses";
    $result = $mysqli->query($query);
?>
<!DOCTYPE html>
<html lang="en">
    <!--Head-->
    <?php include('assets/inc/head.php'); ?>
    <body>
        <div id="wrapper">
            <!-- Topbar -->
            <?php include("assets/inc/nav.php"); ?>
            <!-- Sidebar -->
            <?php include("assets/inc/sidebar.php"); ?>

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid">
                        <!-- Page Title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Warehouse List</h4>
                                </div>
                            </div>
                        </div>

                        <!-- Warehouse Table -->
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">All Warehouses</h4>
                                        <div class="table-responsive">
                                            <table class="table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Warehouse Name</th>
                                                        <th>Location</th>
                                                        <th>Created At</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        if ($result->num_rows > 0) {
                                                            $counter = 1;
                                                            while ($row = $result->fetch_assoc()) {
                                                                echo "<tr>";
                                                                echo "<td>" . $counter++ . "</td>";
                                                                echo "<td>" . htmlspecialchars($row['warehouse_name']) . "</td>";
                                                                echo "<td>" . htmlspecialchars($row['warehouse_location']) . "</td>";
                                                                echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
                                                                echo "</tr>";
                                                            }
                                                        } else {
                                                            echo "<tr><td colspan='4' class='text-center'>No Warehouses Found</td></tr>";
                                                        }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <?php include('assets/inc/footer.php'); ?>
            </div>
        </div>

        <!-- Scripts -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>
    </body>
</html>
