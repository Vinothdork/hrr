<?php
session_start();
include('assets/inc/config.php');

if (isset($_POST['submit_attendance'])) {
    $att_date = $_POST['att_date'];
    if (!empty($_POST['attendance'])) {
        foreach ($_POST['attendance'] as $doc_number => $status) {
            // Skip record creation if status is "Select Status"
            if ($status === 'Select Status') {
                continue;
            }

            // Check if an attendance record already exists for this employee on the selected date
            $check_query = "SELECT * FROM his_attendance WHERE att_date = ? AND att_doc_number = ?";
            $stmt_check = $mysqli->prepare($check_query);
            $stmt_check->bind_param('ss', $att_date, $doc_number);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                // If a record exists, skip inserting the attendance record
                continue;
            }

            // If no record exists, insert a new record
            $check_in_time = isset($_POST['check_in'][$doc_number]) ? $_POST['check_in'][$doc_number] : null;
            $check_out_time = isset($_POST['check_out'][$doc_number]) ? $_POST['check_out'][$doc_number] : null;
            $remarks = $_POST['remarks'][$doc_number];

            $insert_query = "INSERT INTO his_attendance (att_date, att_doc_number, att_status, check_in_time, check_out_time, att_remarks) 
                             VALUES (?, ?, ?, ?, ?, ?)";
            $stmt_insert = $mysqli->prepare($insert_query);
            $stmt_insert->bind_param('ssssss', $att_date, $doc_number, $status, $check_in_time, $check_out_time, $remarks);
            $stmt_insert->execute();
        }

        if ($stmt_insert) {
            $success = "Attendance Recorded Successfully";
        } else {
            $err = "Already Attendance Created for Selected Date";
        }
    } else {
        $err = "No Employee Selected for Attendance.";
    }
}

// Fetch Employee List
$query = "SELECT doc_number, CONCAT(doc_fname, ' ', doc_lname) AS doc_name FROM his_docs";
$result = $mysqli->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>
<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>
        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Record Attendance</h4>
                                    <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
                                    <?php if (isset($err)) echo "<div class='alert alert-danger'>$err</div>"; ?>

                                    <form method="post">
                                        <div class="form-group">
                                            <label for="att_date" class="col-form-label">Attendance Date</label>
                                            <input type="date" required="required" name="att_date" class="form-control" id="att_date">
                                        </div>

                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Employee Name</th>
                                                    <th>Status</th>
                                                    <th>Check-in Time</th>
                                                    <th>Check-out Time</th>
                                                    <th>Remarks</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if ($result->num_rows > 0) : ?>
                                                    <?php $count = 1; while ($row = $result->fetch_assoc()) : ?>
                                                        <tr>
                                                            <td><?= $count++; ?></td>
                                                            <td><?= $row['doc_name']; ?></td>
                                                            <td>
                                                                <select name="attendance[<?= $row['doc_number']; ?>]" class="form-control">
                                                                    <option value="Select Status">Select Status</option>
                                                                    <option value="Present">Present</option>
                                                                    <option value="Absent">Absent</option>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <input type="time" name="check_in[<?= $row['doc_number']; ?>]" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="time" name="check_out[<?= $row['doc_number']; ?>]" class="form-control">
                                                            </td>
                                                            <td>
                                                                <input type="text" name="remarks[<?= $row['doc_number']; ?>]" class="form-control" placeholder="Optional">
                                                            </td>
                                                        </tr>
                                                    <?php endwhile; ?>
                                                <?php else : ?>
                                                    <tr>
                                                        <td colspan="6">No Employees Found</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>

                                        <button type="submit" name="submit_attendance" class="btn btn-success">Submit Attendance</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>

    <div class="rightbar-overlay"></div>
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>
