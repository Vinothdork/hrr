<!DOCTYPE html>
<html lang="en">

<?php 
session_start(); 
include('assets/inc/config.php'); 
include('assets/inc/checklogin.php'); 
check_login();
$aid=$_SESSION['ad_id']; 
?>

<?php include('assets/inc/head.php');?>

<head>
    <style>
        .receipt-entry {
            color: green;
        }
        .issue-entry {
            color: red;
        }
    </style>
</head>

<body>

    <!-- Begin page -->
    <div id="wrapper">

        <!-- Topbar Start -->
        <?php include('assets/inc/nav.php');?>
        <!-- end Topbar -->

        <!-- Left Sidebar Start -->
        <?php include("assets/inc/sidebar.php");?>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Stock Entries</a></li>
                                        <li class="breadcrumb-item active">Stock Entries Report</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Stock Entries Report</h4>
                            </div>
                        </div>
                    </div>     
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card-box">
                                <h4 class="header-title">Report of Stock Entries</h4>
                                <div class="mb-2">
                                    <div class="row">
                                        <div class="col-12 text-sm-center form-inline">
                                            <!-- Search by Item -->
                                            <div class="form-group mr-2">
                                                <input id="demo-foo-search" type="text" placeholder="Search by Item" class="form-control form-control-sm" autocomplete="on">
                                            </div>
                                            <!-- Search by Warehouse -->
                                            <div class="form-group mr-2">
                                                <input id="warehouse-search" type="text" placeholder="Search by Warehouse" class="form-control form-control-sm" autocomplete="on">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                                    <table id="demo-foo-filtering" class="table table-bordered toggle-circle mb-0">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Item ID</th>
                                                <th>Item Name</th>
                                                <th>Entry Type</th>
                                                <th>Quantity</th>
                                                <th>Balance Quantity (Warehouse)</th>
                                                <th>Warehouse</th>
                                                <th>Remarks</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // Create an associative array to store balance quantities by Warehouse and Item
                                            $balances_by_warehouse = array();
                                            
                                            // Fetch stock entries
                                            $ret = "SELECT * FROM stock_entries";
                                            $stmt = $mysqli->prepare($ret);
                                            $stmt->execute();
                                            $res = $stmt->get_result();
                                            $cnt = 1;
                                            while($row = $res->fetch_object()) {
                                                // Initialize warehouse balance array if not already set
                                                if (!isset($balances_by_warehouse[$row->warehouse])) {
                                                    $balances_by_warehouse[$row->warehouse] = array();
                                                }
                                                if (!isset($balances_by_warehouse[$row->warehouse][$row->phar_id])) {
                                                    $balances_by_warehouse[$row->warehouse][$row->phar_id] = 0;
                                                }

                                                // Calculate the balance for each warehouse and item
                                                if ($row->entry_type == 'receipt') {
                                                    $balances_by_warehouse[$row->warehouse][$row->phar_id] += $row->entry_quantity;  // Add quantity for receipt
                                                } else if ($row->entry_type == 'issue') {
                                                    $balances_by_warehouse[$row->warehouse][$row->phar_id] -= $row->entry_quantity;  // Subtract quantity for issue
                                                }
                                                
                                                // Get the current balance for this warehouse and item
                                                $current_balance_warehouse = $balances_by_warehouse[$row->warehouse][$row->phar_id];
                                                
                                                // Determine class for the quantity based on entry type
                                                $quantity_class = ($row->entry_type == 'receipt') ? 'receipt-entry' : 'issue-entry';
                                            ?>
                                                <tr>
                                                    <td><?php echo $cnt; ?></td>
                                                    <td><?php echo $row->phar_id; ?></td>
                                                    <td><?php echo $row->phar_name; ?></td>
                                                    <td><?php echo $row->entry_type; ?></td>
                                                    <td class="<?php echo $quantity_class; ?>"><?php echo $row->entry_quantity; ?></td> <!-- Apply red color to quantity based on entry type -->
                                                    <td><?php echo $current_balance_warehouse; ?></td>  <!-- Display balance for this warehouse and item -->
                                                    <td><?php echo $row->warehouse; ?></td>
                                                    <td><?php echo $row->remarks; ?></td>
                                                    <td><?php echo $row->entry_date; ?></td>
                                                </tr>
                                            <?php 
                                                $cnt++; 
                                            } ?>
                                        </tbody>
                                    </table>
                                </div> <!-- end .table-responsive-->
                            </div> <!-- end card-box -->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- container -->

            </div> <!-- content -->

            <!-- Footer Start -->
            <?php include('assets/inc/footer.php');?>
            <!-- end Footer -->

        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->

    </div>
    <!-- END wrapper -->


    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- Footable js -->
    <script src="assets/libs/footable/footable.all.min.js"></script>

    <!-- Init js -->
    <script src="assets/js/pages/foo-tables.init.js"></script>

    <!-- App js -->
    <script src="assets/js/app.min.js"></script>

    <script>
    $(document).ready(function() {
        // Apply dual filtering (Search by Item and Search by Warehouse) simultaneously
        $('#demo-foo-search, #warehouse-search').on('keyup', function() {
            var itemSearchTerm = $('#demo-foo-search').val().toLowerCase();
            var warehouseSearchTerm = $('#warehouse-search').val().toLowerCase();

            $('#demo-foo-filtering tbody tr').each(function() {
                var row = $(this);
                var itemName = row.find('td:nth-child(3)').text().toLowerCase();  // Item Name
                var itemId = row.find('td:nth-child(2)').text().toLowerCase();    // Item ID
                var warehouse = row.find('td:nth-child(7)').text().toLowerCase();  // Warehouse

                // Check if the row matches both the item and warehouse filters
                var showRow = true;

                // If Item search term is present, check if item name or item ID matches
                if (itemSearchTerm && !(itemName.indexOf(itemSearchTerm) > -1 || itemId.indexOf(itemSearchTerm) > -1)) {
                    showRow = false;
                }

                // If Warehouse search term is present, check if warehouse matches
                if (warehouseSearchTerm && !(warehouse.indexOf(warehouseSearchTerm) > -1)) {
                    showRow = false;
                }

                // Show or hide row based on both search conditions
                if (showRow) {
                    row.show();
                } else {
                    row.hide();
                }
            });
        });
    });
</script>


</body>

</html>

