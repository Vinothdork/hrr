<?php
session_start();
include('assets/inc/config.php');

// Initialize filter variables
$att_date_filter = '';
$status_filter = '';
$employee_name_filter = '';

// Handle the search form submission
if (isset($_POST['search'])) {
    $att_date_filter = $_POST['att_date'];
    $status_filter = $_POST['status'];
    $employee_name_filter = $_POST['employee_name'];
}

// Build the query with the filters
$query = "SELECT his_attendance.*, his_docs.doc_fname, his_docs.doc_lname 
          FROM his_attendance
          LEFT JOIN his_docs ON his_attendance.att_doc_number = his_docs.doc_number
          WHERE 1=1";

if ($att_date_filter) {
    $query .= " AND att_date = '$att_date_filter'";
}
if ($status_filter) {
    $query .= " AND att_status = '$status_filter'";
}
if ($employee_name_filter) {
    $query .= " AND (his_docs.doc_fname LIKE '%$employee_name_filter%' OR his_docs.doc_lname LIKE '%$employee_name_filter%')";
}

$query .= " ORDER BY att_date DESC";

$result = $mysqli->query($query);

// Function to calculate total working hours
function calculate_working_hours($check_in, $check_out) {
    $check_in_time = new DateTime($check_in);
    $check_out_time = new DateTime($check_out);
    $interval = $check_in_time->diff($check_out_time);
    return $interval->format('%h hours %i minutes');
}

?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>
<body>
    <div id="wrapper">
        <?php include("assets/inc/nav.php"); ?>
        <?php include("assets/inc/sidebar.php"); ?>
        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="header-title">Attendance List</h4>

                                    <!-- Search Form -->
                                    <form method="post">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <input type="date" name="att_date" class="form-control" value="<?= $att_date_filter ?>">
                                            </div>
                                            <div class="col-md-3">
                                                <input type="text" name="employee_name" class="form-control" placeholder="Employee Name" value="<?= $employee_name_filter ?>">
                                            </div>
                                            <div class="col-md-3">
                                                <select name="status" class="form-control">
                                                    <option value="">Select Status</option>
                                                    <option value="Present" <?= $status_filter == 'Present' ? 'selected' : ''; ?>>Present</option>
                                                    <option value="Absent" <?= $status_filter == 'Absent' ? 'selected' : ''; ?>>Absent</option>
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <button type="submit" name="search" class="btn btn-primary">Search</button>
                                            </div>
                                        </div>
                                    </form>

                                    <!-- Attendance Table -->
                                    <table class="table table-bordered mt-4">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Employee Name</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th>Check-in Time</th>
                                                <th>Check-out Time</th>
                                                <th>Remarks</th>
                                                <th>Total Working Hours</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if ($result->num_rows > 0) : ?>
                                                <?php $count = 1; while ($row = $result->fetch_assoc()) : ?>
                                                    <tr>
                                                        <td><?= $count++; ?></td>
                                                        <td><?= $row['doc_fname'] . ' ' . $row['doc_lname']; ?></td>
                                                        <td><?= $row['att_date']; ?></td>
                                                        <td><?= $row['att_status']; ?></td>
                                                        <td><?= $row['check_in_time']; ?></td>
                                                        <td><?= $row['check_out_time']; ?></td>
                                                        <td><?= $row['att_remarks']; ?></td>
                                                        <td>
                                                            <?php
                                                            if ($row['check_in_time'] && $row['check_out_time']) {
                                                                echo calculate_working_hours($row['check_in_time'], $row['check_out_time']);
                                                            } else {
                                                                echo "N/A";
                                                            }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            <?php else : ?>
                                                <tr>
                                                    <td colspan="8">No Attendance Records Found</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('assets/inc/footer.php'); ?>
        </div>
    </div>

    <div class="rightbar-overlay"></div>
    <script src="assets/js/vendor.min.js"></script>
    <script src="assets/js/app.min.js"></script>
</body>
</html>
