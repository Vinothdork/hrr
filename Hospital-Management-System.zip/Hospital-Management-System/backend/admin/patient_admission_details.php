<?php
session_start();
include('assets/inc/config.php');

// Fetch all admitted patients from the database
$admitted_patients = [];
$query = "SELECT pa.admission_id, p.pat_fname, p.pat_lname, pa.admission_reason, pa.admission_date 
          FROM patient_admissions pa
          INNER JOIN his_patients p ON pa.pat_id = p.pat_id";
$result = $mysqli->query($query);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $admitted_patients[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include('assets/inc/head.php'); ?>
<body>
<div id="wrapper">
    <?php include("assets/inc/nav.php"); ?>
    <?php include("assets/inc/sidebar.php"); ?>

    <div class="content-page">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Patient Admission</h4>
                                
                                <!-- Form to admit a patient (same as the previous code) -->
                                <!-- (You can leave the previous form here, no changes needed for the admission form) -->
                                
                                <!-- Success/Error message -->
                                <?php if (isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
                                <?php if (isset($err)) echo "<div class='alert alert-danger'>$err</div>"; ?>

                                <!-- List View of Admitted Patients -->
                                <h4 class="header-title mt-4">Admitted Patients</h4>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Admission ID</th>
                                            <th>Patient Name</th>
                                            <th>Reason for Admission</th>
                                            <th>Admission Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($admitted_patients) > 0): ?>
                                            <?php foreach ($admitted_patients as $patient): ?>
                                                <tr>
                                                    <td><?php echo $patient['admission_id']; ?></td>
                                                    <td><?php echo $patient['pat_fname'] . ' ' . $patient['pat_lname']; ?></td>
                                                    <td><?php echo $patient['admission_reason']; ?></td>
                                                    <td><?php echo $patient['admission_date']; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="text-center">No admitted patients found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include('assets/inc/footer.php'); ?>
    </div>
</div>

<script src="assets/js/vendor.min.js"></script>
<script src="assets/js/app.min.js"></script>
</body>
</html>
